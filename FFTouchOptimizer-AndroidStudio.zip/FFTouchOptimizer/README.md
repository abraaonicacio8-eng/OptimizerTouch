# FF Touch Optimizer

Projeto inicial Android para Android Studio.

## V1
- Tela principal
- Verificação básica de resolução/densidade
- Teste visual de touch
- Calculadora simples de faixa de sensibilidade
- Estrutura inicial para presets

## Importante
O app não altera arquivos do Free Fire, não injeta comandos, não usa macro/aimbot e não promete aumentar o FPS além das capacidades do aparelho.

Abra a pasta no Android Studio e aguarde o Gradle sincronizar.
