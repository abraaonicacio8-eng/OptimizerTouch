package com.example.fftouchoptimizer

import android.os.Bundle
import android.view.MotionEvent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var presetName: EditText
    private lateinit var dpiInput: EditText
    private lateinit var sensInput: EditText
    private lateinit var presets: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "FF TOUCH OPTIMIZER"
            textSize = 26f
        }
        status = TextView(this).apply {
            text = "Redmi Note 15 4G • modo seguro"
            textSize = 16f
        }

        val touch = Button(this).apply {
            text = "👆 Teste de Touch"
            setOnClickListener { showTouchTest() }
        }
        val calc = Button(this).apply {
            text = "🎯 Calculadora de Sensibilidade"
            setOnClickListener { showCalculator() }
        }
        val optimize = Button(this).apply {
            text = "⚡ Verificar dispositivo"
            setOnClickListener {
                val wm = resources.displayMetrics
                status.text = "Tela: ${wm.widthPixels} × ${wm.heightPixels} px\nDensidade: ${wm.densityDpi} dpi"
            }
        }

        presets = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        root.addView(title)
        root.addView(status)
        root.addView(touch)
        root.addView(calc)
        root.addView(optimize)
        root.addView(TextView(this).apply {
            text = "\n💾 Presets"
            textSize = 20f
        })
        root.addView(presets)

        setContentView(root)
    }

    private fun showCalculator() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "🎯 Calculadora de Sensibilidade"
            textSize = 24f
        })

        dpiInput = EditText(this).apply {
            hint = "DPI (ex.: 400)"
            inputType = 2
        }
        sensInput = EditText(this).apply {
            hint = "Sensibilidade atual (0–200)"
            inputType = 2
        }
        val result = TextView(this).apply { textSize = 18f }

        val calculate = Button(this).apply {
            text = "Calcular faixa inicial"
            setOnClickListener {
                val dpi = dpiInput.text.toString().toIntOrNull() ?: 400
                val sens = sensInput.text.toString().toIntOrNull() ?: 100
                val factor = (dpi / 400.0)
                val suggested = (sens / factor).roundToInt().coerceIn(1, 200)
                result.text = "Faixa para testar: ${maxOf(1, suggested - 8)}–${minOf(200, suggested + 8)}\n\nIsso é uma referência de teste, não altera o Free Fire automaticamente."
            }
        }

        val back = Button(this).apply {
            text = "← Voltar"
            setOnClickListener { showHome() }
        }

        root.addView(dpiInput)
        root.addView(sensInput)
        root.addView(calculate)
        root.addView(result)
        root.addView(back)
        setContentView(root)
    }

    private fun showTouchTest() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(TextView(this).apply {
            text = "👆 TESTE DE TOUCH — arraste o dedo pela área abaixo"
            textSize = 18f
            setPadding(24, 24, 24, 24)
        })
        val area = FrameLayout(this)
        val info = TextView(this).apply {
            text = "Toque para começar"
            textSize = 18f
            setPadding(24, 24, 24, 24)
        }
        area.addView(info)
        area.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE ->
                    info.text = "X: ${event.x.roundToInt()}  Y: ${event.y.roundToInt()}\nPointer: ${event.pointerCount}"
                MotionEvent.ACTION_UP ->
                    info.text = "Toque finalizado"
            }
            true
        }
        root.addView(area, LinearLayout.LayoutParams(-1, 0, 1f))
        val back = Button(this).apply {
            text = "← Voltar"
            setOnClickListener { showHome() }
        }
        root.addView(back)
        setContentView(root)
    }
}
